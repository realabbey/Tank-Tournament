# Tank Tournament — Pure HTML

This version requires no Node.js, Replit, Qoder, server, database, or installation.

## Run it
Double-click `index.html`.

The website opens directly in your browser.

## Included
- Home page
- Competitions
- Local competition registration
- Rankings
- Player directory/search
- News
- Rules
- Sign in / account creation
- Responsive design
- Local browser storage for accounts and registrations

## Important
This is a front-end/local version. Accounts and registrations are stored in the browser's localStorage, so they are not shared between different devices or browsers.

For a real public website with shared accounts, a backend/database would be needed.
